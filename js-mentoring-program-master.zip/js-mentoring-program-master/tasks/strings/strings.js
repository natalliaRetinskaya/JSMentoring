/**
 * 1. Calculate a century by given year
 * if a number is passed
* @param {number}
*/
function centuryFromYear(year) {
  
}

/**
 * Calculate count of the provided char in the string
 * @param {string}
 * @param {string}
 */
function strCount(str, char) { 
}

/**
 * We need to reduce the length of the string or truncate it if it is longer 
 * than the given maximum length specified and add ... to the end. If it is not that long then we keep it as is.
 * @param {string} - the initial string
 * @param {num} - by wht amount of chars it should be truncated
 */
function truncateString(str,num) { 
}

module.exports = {
  centuryFromYear,
  strCount,
  truncateString
};