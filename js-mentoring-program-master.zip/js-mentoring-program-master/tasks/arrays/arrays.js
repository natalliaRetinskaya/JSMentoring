/**
 * 1. Write a method to reverse a string; Function should return the string 'This is not a string'
 * if a number is passed
* @param {string}
*/
function reverseString(str) {
}

/**
 * return an array of characters names
 */
function getCharactersNames(chars) {
}

/**
 * print (console.log) ids of all characters
 */
function printCharacterNames(chars) {
}

/**
 * return an array of non-human characters
 */
function getNonHumanCharacters(chars) {
}

/**
 * return info about character named 'Jerry Smith'
 */
function getJerryInfo(chars) {
}

/**
 * check if all characters are human. return true if all, false if not
 */
function isAllHuman(chars) {
}

/**
 * check if there are any Fish-Person characters. return true if any, false if not
 */
function isAnyFishPerson(chars) {
}

/**
 * 1. Write a method to find an index of minimal item from an array;
* @param {array}
*/
function minItem(arr) {
    //PLACE YOUR CODE HERE
  }

module.exports = {
    reverseString,
    getCharactersNames,
    printCharacterNames,
    getNonHumanCharacters,
    getJerryInfo,
    isAllHuman,
    isAnyFishPerson,
    minItem
};
