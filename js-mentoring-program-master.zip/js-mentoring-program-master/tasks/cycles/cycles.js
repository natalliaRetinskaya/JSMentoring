/**
 * Write the function that will calculate the amonut of discout 
 * considering the redemption amount
 * Rules are the following:
 * - 0    - 350:  0%
 * - 351  - 1350: 15%
 * - 1351 - 2700: 30%
 * - 2701 - 6500: 45%
 * @param {number} redemption amount (0 - 9999)
 * @returns {number} discount in percent
 */

function calculateDiscount(redemption) {
  let discount;
  
  //PLACE YOUR CODE HERE

  return discount;
}

module.exports = calculateDiscount;