var one = 1;
let second = 2;
const pi = 3.14;


console.log(pi);