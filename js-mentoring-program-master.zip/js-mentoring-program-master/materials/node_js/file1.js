const str = 'Hello World!';

module.exports = str;