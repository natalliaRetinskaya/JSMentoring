const str1 = require('./file1');

console.log(str1);